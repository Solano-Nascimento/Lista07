package Ex02;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

import java.math.BigDecimal;

import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import Ex01.FatorialController;
import Ex01.FatorialView;


/**
 * Um teste de aceitação diferentemente de um teste automatizado, implementa passo a passos mais manuais e que dependem da 
 * experiência do usuário em analisar se o resultado obtido está correto ou não. Segue abaixo um exemplo simples de como um teste de execução pode
 * ser executado:
 * Teste de Aceitação para Calculadora de Fatorial
 *
 * Instruções para o usuário/testador:
 * - Inicie a aplicação FatorialView.
 * - Para cada conjunto de dados de teste:
 *   1. Insira o valor no campo de entrada.
 *   2. Clique no botão "Calcular".
 *   3. Observe o resultado na área de texto:
 *      - Se o resultado for numérico, compare com o esperado.
 *      - Se inserir um valor inválido (como um negativo), verifique se uma mensagem de erro adequada é exibida.
 * - Documente os resultados de cada teste, notando se estão corretos ou se há discrepâncias.
 * - Use automação parcial (como o Sikuli) para capturar e verificar automaticamente o resultado, se possível. Caso contrário, continue com verificações manuais.
 *
 * Este teste avaliará a funcionalidade e a robustez da interface do usuário, assim como a precisão do cálculo do fatorial.
 */


public class FatorialControllerTest {
	
	FatorialView janela = new FatorialView();
	JButton calculateButton = janela.getButton();
	JTextField inputField = janela.getInputField();
	JTextArea resultArea = janela.getResultArea();
	
   
	
	@BeforeAll
	public void setUp() {
		
        FatorialView janela = new FatorialView();

        System.out.println("Aqui");
		calculateButton = janela.getButton();
		inputField = janela.getInputField();
		resultArea = janela.getResultArea();
		
	}

    @Test
    public void testFatorial() throws InterruptedException {
    	inputField.setText("10");
    	calculateButton.doClick();
    	Thread.sleep(1000);
    	assertEquals("3628800", resultArea.getText());
    	
    	
    }
    
    @Test
    public void testFatorialNegative() {
    	inputField.setText("-10");
    	calculateButton.doClick();
    	
    }
    
    @Test
    public void testFatorialInvalid() {
    	inputField.setText("ab");
    	calculateButton.doClick();
    	
    }

}
