package Ex01;

import java.math.BigDecimal;
import java.util.function.IntConsumer;

public class FatorialController {
    public static BigDecimal calcularFatorial(int num, IntConsumer progressUpdater) {
        if (num < 0) {
            throw new IllegalArgumentException("Número deve ser não negativo.");
        }

        BigDecimal resultado = BigDecimal.ONE;
        for (int i = 1; i <= num; i++) {
            resultado = resultado.multiply(BigDecimal.valueOf(i));
            if (progressUpdater != null) {
                int progress = (i * 100) / num;
                progressUpdater.accept(progress);
            }
        }
        return resultado;
    }
}
